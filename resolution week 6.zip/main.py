import machine
from machine import Pin, SPI, PWM
import time
import max7219
import dht
from hcsr04 import HCSR04

time.sleep(0.1) # Wait for USB to become ready

spi = SPI(0, baudrate=10000000, polarity=1, phase=0, sck=Pin(2), mosi=Pin(3))
ss = Pin(5, Pin.OUT)

display = max7219.Matrix8x8(spi, ss, 8)


d = dht.DHT22(machine.Pin(22))

display.brightness(15)

sensor = HCSR04(trigger_pin=28, echo_pin=27)

danger = False

buzzer = PWM(Pin(21))
button = Pin(26, Pin.IN, Pin.PULL_UP)
buzzer_on = False


while True:
  d.measure()
  temp = (d.temperature())
  hum = (d.humidity())
  text_temp = "Temperature:" + str(temp) + " C"
  lenght_temp = len(text_temp) *8
  text_hum = "Humidity:" + str(hum) + "%"
  lenght_hum = len(text_hum) *8
  distance = sensor.distance_cm()

  if distance <= 50:
    display.fill(0)
    display.text("Warning", 0, 0, 1)
    display.show()
    danger = True
  else:
    for x in range(64, -lenght_temp, -1):
      display.fill(0)
      display.text(text_temp, x, 0, 1)
      display.show()
      time.sleep(0.05)
      distance = sensor.distance_cm()
      if distance <= 50:
        danger = True
        break
  
    for x in range(64, -lenght_hum, -1):
      display.fill(0)
      display.text(text_hum, x, 0, 1)
      display.show()
      time.sleep(0.05)
      distance = sensor.distance_cm()
      if distance <= 50:
        danger = True
        break
  while danger:
    print("danger")
    display.fill(0)
    display.text("Warning", 0, 0, 1)
    display.show()
    for f in range(2000, 400, -15):
      print("buzzer")
      buzzer.freq(f)
      buzzer.duty_u16(6000)
      time.sleep(0.01)
      if button.value() == 0:
        buzzer.duty_u16(0)
        danger = False
        break
        
    for f in range(400, 2000, 20):
      print("buzzer")
      buzzer.freq(f)
      buzzer.duty_u16(6000)
      time.sleep(0.01)
      if button.value() == 0:
        buzzer.duty_u16(0)
        danger = False
        break
       

    if button.value() == 0:
      buzzer.duty_u16(0)
      danger = False
      break
   

  
 

